<?php
// Secure session configuration
ini_set('session.cookie_httponly', 1);
ini_set('session.cookie_secure', 1);
ini_set('session.use_strict_mode', 1);
session_start();

// Set security headers
header("X-Frame-Options: DENY");
header("X-Content-Type-Options: nosniff");
header("X-XSS-Protection: 1; mode=block");
header("Referrer-Policy: strict-origin-when-cross-origin");

// Include required files
require '../includes/connect.php';
require '../includes/calculate-hours.php';

// Add this helper function after the initial require statements
function formatHoursAndMinutes($hours) {
    $fullHours = floor($hours);
    $minutes = round(($hours - $fullHours) * 60);
    return $fullHours . "h " . $minutes . "m";
}

// Session timeout handling (30 min)
$inactivity = 1800;
if (isset($_SESSION['last_activity']) && time() - $_SESSION['last_activity'] > $inactivity) {
    session_unset();
    session_destroy();
    setcookie(session_name(), '', time() - 3600, '/');
    header("Location: ../index.php");
    exit();
}
$_SESSION['last_activity'] = time();

// Authentication check
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'sip_supervisor' || !isset($_SESSION['sip_supervisor_logged_in'])) {
    session_destroy();
    setcookie(session_name(), '', time() - 3600, '/');
    header("Location: ../index.php");
    exit();
}

// Session security
if (!isset($_SESSION['created'])) {
    $_SESSION['created'] = time();
} elseif (time() - $_SESSION['created'] > 1800) {
    session_regenerate_id(true);
    $_SESSION['created'] = time();
}

// Handle logout
if (isset($_GET['action']) && $_GET['action'] === 'logout') {
    session_unset();
    session_destroy();
    setcookie(session_name(), '', time() - 3600, '/');
    header("Location: ../index.php");
    exit();
}

$identifier = $_SESSION['identifier'] ?? null;

// Fetch SIP Supervisor info
$stmt = $conn->prepare("SELECT * FROM sip_supervisors WHERE username = ?"); 
if (!$stmt) {
    die("Database error: " . $conn->error);
}
$stmt->bind_param("s", $identifier);
$stmt->execute();
$supervisor = $stmt->get_result()->fetch_assoc();
$stmt->close();

if (!$supervisor) {
    die("SIP Supervisor not found.");
}

// Get the total counts and hours
$stats_query = $conn->prepare("
    SELECT 
        COUNT(DISTINCT s.student_id) as total_students,
        COALESCE(SUM(
            CASE 
                WHEN tt.confirmation_status = 1 
                     AND tt.clock_out IS NOT NULL 
                     AND TIME(tt.clock_in) NOT BETWEEN '12:00:00' AND '13:00:00'
                     AND TIME(tt.clock_out) NOT BETWEEN '12:00:00' AND '13:00:00'
                THEN 
                    TIMESTAMPDIFF(SECOND, tt.clock_in, tt.clock_out) / 3600 -
                    CASE 
                        WHEN TIME(tt.clock_in) < '12:00:00' AND TIME(tt.clock_out) > '13:00:00'
                        THEN 1 -- Deduct 1 hour for lunch break
                        ELSE 0
                    END
                ELSE 0 
            END
        ), 0) as total_confirmed_hours
    FROM students s
    LEFT JOIN time_tracking tt ON s.student_id = tt.student_id
    WHERE s.sip_center = ?
");

if (!$stats_query) {
    die("Query preparation failed: " . $conn->error);
}

$stats_query->bind_param("s", $supervisor['sip_center']);
$stats_query->execute();
$stats = $stats_query->get_result()->fetch_assoc();
$stats_query->close();

// Assign values from stats query
$total_students = $stats['total_students'];
$total_confirmed_hours = formatHoursAndMinutes($stats['total_confirmed_hours']);

// Calculate average progress
$progress_query = $conn->prepare("
    SELECT 
        s.student_id,
        COALESCE(SUM(
            CASE 
                WHEN tt.confirmation_status = 1 AND tt.clock_out IS NOT NULL
                THEN TIMESTAMPDIFF(HOUR, tt.clock_in, tt.clock_out) +
                     TIMESTAMPDIFF(MINUTE, tt.clock_in, tt.clock_out) % 60 / 60
                ELSE 0 
            END
        ), 0) as student_hours,
        COALESCE(sv.required_hours, 300) as required_hours
    FROM students s
    LEFT JOIN time_tracking tt ON s.student_id = tt.student_id
    LEFT JOIN supervisors sv ON s.supervisor = sv.id
    WHERE s.sip_center = ?
    GROUP BY s.student_id, sv.required_hours
");

$progress_query->bind_param("s", $supervisor['sip_center']);
$progress_query->execute();
$progress_result = $progress_query->get_result();

$total_progress = 0;
$student_count = 0;

while ($row = $progress_result->fetch_assoc()) {
    $student_progress = min(100, ($row['student_hours'] / $row['required_hours']) * 100);
    $total_progress += $student_progress;
    $student_count++;
}

$average_progress = $student_count > 0 ? round($total_progress / $student_count, 1) : 0;
$progress_query->close();

// Fetch student details with hours
$intern_stmt = $conn->prepare("
    SELECT 
        s.student_id,
        s.fullname,
        s.course,
        s.school_year,
        sv.required_hours,
        COALESCE(SUM(
            CASE 
                WHEN tt.confirmation_status = 1 
                     AND tt.clock_out IS NOT NULL 
                     AND TIME(tt.clock_in) NOT BETWEEN '12:00:00' AND '13:00:00'
                     AND TIME(tt.clock_out) NOT BETWEEN '12:00:00' AND '13:00:00'
                THEN 
                    TIMESTAMPDIFF(HOUR, tt.clock_in, tt.clock_out) +
                    TIMESTAMPDIFF(MINUTE, tt.clock_in, tt.clock_out) % 60 / 60 -
                    CASE 
                        WHEN TIME(tt.clock_in) < '12:00:00' AND TIME(tt.clock_out) > '13:00:00'
                        THEN 1 -- Deduct 1 hour for lunch break
                        ELSE 0
                    END
                ELSE 0 
            END
        ), 0) as confirmed_hours,
        COALESCE(SUM(
            CASE 
                WHEN tt.clock_out IS NOT NULL AND tt.confirmation_status = 0
                THEN TIMESTAMPDIFF(HOUR, tt.clock_in, tt.clock_out) +
                     TIMESTAMPDIFF(MINUTE, tt.clock_in, tt.clock_out) % 60 / 60
                ELSE 0 
            END
        ), 0) as pending_hours
    FROM students s
    LEFT JOIN time_tracking tt ON s.student_id = tt.student_id
    LEFT JOIN supervisors sv ON s.supervisor = sv.id
    WHERE s.sip_center = ?
    GROUP BY s.student_id, s.fullname, s.course, s.school_year, sv.required_hours
");

if (!$intern_stmt) {
    die("Database error: " . $conn->error);
}
$intern_stmt->bind_param("s", $supervisor['sip_center']);
$intern_stmt->execute();
$interns_result = $intern_stmt->get_result();

$interns_data = [];

while ($intern = $interns_result->fetch_assoc()) {
    $required_hours = !empty($intern['required_hours']) ? floatval($intern['required_hours']) : 300;
    $confirmed_hours = floatval($intern['confirmed_hours']);
    $progress = ($required_hours > 0) ? min(100, ($confirmed_hours / $required_hours) * 100) : 0;
    
    $interns_data[] = [
        'student_id' => $intern['student_id'],
        'fullname' => $intern['fullname'],
        'course' => $intern['course'],
        'school_year' => $intern['school_year'],
        'confirmed_hours' => formatHoursAndMinutes($confirmed_hours),
        'pending_hours' => formatHoursAndMinutes(floatval($intern['pending_hours'])),
        'progress' => round($progress, 1)
    ];
}

$intern_stmt->close();
?>



<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title> Center Supervisor Dashboard</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet">
    <link href="../css/sip-supervisor-dashboard.css" rel="stylesheet">
</head>
<body>

<nav class="navbar navbar-expand-lg mb-4">
    <div class="container-fluid">
        <a class="navbar-brand" href="#">
            <i class="fas fa-chart-line"></i>
             Center Supervisor Dashboard
        </a>
        <div class="ms-auto">
            <a class="btn btn-logout d-flex align-items-center gap-2" href="../index.php" title="Logout">
                <i class="fas fa-sign-out-alt"></i>
                Logout
            </a>
        </div>
    </div>
</nav>

<div class="content-wrapper">
    <div class="container">
        <div class="card welcome-card">
            <div class="d-flex justify-content-between align-items-center">
                <div>
                    <h3>Welcome, <?= htmlspecialchars($supervisor['fullname']) ?></h3>
                    <p class="mb-0"><i class="fas fa-building me-2"></i> <?= htmlspecialchars($supervisor['sip_center']) ?></p>
                </div>
                <div class="avatar-initial" style="width: 60px; height: 60px; font-size: 1.5rem;">
                    <?= strtoupper(substr($supervisor['fullname'], 0, 1)) ?>
                </div>
            </div>
        </div>

        <!-- Summary Cards -->
        <div class="row text-center my-4">
            <div class="col-md-4">
                <div class="card summary-card">
                    <h5><i class="fas fa-users"></i>Total Interns</h5>
                    <p><?= $total_students ?></p>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card summary-card">
                    <h5><i class="fas fa-clock"></i>Total Confirmed Hours</h5>
                    <p><?= $total_confirmed_hours ?></p>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card summary-card">
                    <h5><i class="fas fa-chart-pie"></i>Average Progress</h5>
                    <p><?= $average_progress ?>%</p>
                </div>
            </div>
        </div>

        <!-- Intern Table -->
        <div class="card">
            <div class="card-header">
                <h4><i class="fas fa-list"></i>Assigned Student Interns</h4>
            </div>
            <div class="table-responsive">
                <table class="table table-hover">
                    <thead>
                        <tr>
                            <th>Student ID</th>
                            <th>Student Name</th>
                            <th>Course</th>
                            <th>School Year</th>
                            <th>Total Hours </th>
                            <th>Progress</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php foreach ($interns_data as $intern):
                        $barColor = $intern['progress'] >= 100 ? 'bg-success' : ($intern['progress'] >= 50 ? 'bg-warning' : 'bg-info');
                        $initial = strtoupper(substr($intern['fullname'], 0, 1));
                    ?>
                        <tr>
                            <td><?= htmlspecialchars($intern['student_id']) ?></td>
                            <td>
                                <div class="d-flex align-items-center">
                                    <div class="avatar-initial"><?= $initial ?></div>
                                    <?= htmlspecialchars($intern['fullname']) ?>
                                </div>
                            </td>
                            <td><?= htmlspecialchars($intern['course']) ?></td> 
                            <td><?= htmlspecialchars($intern['school_year']) ?></td> 
                            
                            <td><?= $intern['confirmed_hours'] ?> </td>
                            <td>
                                <div class="progress mb-1">
                                    <div class="progress-bar <?= $barColor ?>" role="progressbar" style="width: <?= $intern['progress'] ?>%;"></div>
                                </div>
                                <small class="text-muted"><?= $intern['progress'] ?>% Complete</small>
                            </td>
                            <td>
                                <a href="../views/daily-time-records.php?student_id=<?= urlencode($intern['student_id']) ?>" 
                                   class="btn btn-primary btn-sm">
                                    <i class="fas fa-eye"></i>View Records
                                </a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<footer class="footer">
    © 2025 Student Progress Tracking System. All rights reserved.
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>

